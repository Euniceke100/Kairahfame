import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Boost from "./pages/Boost";
import Templates from "./pages/Templates";
import Login from "./pages/Login";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/boost" element={<Boost />} />
        <Route path="/templates" element={<Templates />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}