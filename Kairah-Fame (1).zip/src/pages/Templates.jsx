import React from "react";
export default function Templates() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-purple-700">Viral Templates</h2>
      <p className="mt-2">Explore short-form viral video templates here soon.</p>
    </div>
  );
}