import React from "react";
export default function Home() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold text-purple-800">Welcome to Kairah Fame</h1>
      <p className="mt-2 text-gray-600">Your viral growth journey starts here.</p>
    </div>
  );
}