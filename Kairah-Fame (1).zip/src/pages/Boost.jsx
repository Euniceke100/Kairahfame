import React from "react";
export default function Boost() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-purple-700">Boost Tools</h2>
      <p className="mt-2">Coming soon: AI scripts, trending audio, hashtags & more.</p>
    </div>
  );
}