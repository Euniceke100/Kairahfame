import React from "react";
export default function Login() {
  return (
    <div className="p-6 text-center">
      <h2 className="text-2xl font-semibold">Sign In</h2>
      <p className="text-gray-500">Firebase Auth setup will be added here.</p>
    </div>
  );
}